import React, { useState } from "react";
import './styles.css';
const RACES = ["Elf", "Dwarf", "Human", "Wizard"];
const CLASSES = ["Warrior", "Mage", "Rogue"];

const INITIAL_STATS = {
  level: 1,
  xp: 0,
  xpToNext: 100,
  hp: 100,
  maxHp: 100,
  mp: 50,
  maxMp: 50,
  strength: 10,
  intelligence: 10,
  agility: 10,
  gold: 100,
  skillPoints: 0,
};

const TABS = {
  PROFILE: "Profile",
  INVENTORY: "Inventory",
  QUESTS: "Quests",
  COMBAT: "Combat",
  SKILLS: "Skills",
  MAP: "Map",
};

const starterInventory = [
  { id: 1, name: "Wooden Sword", type: "weapon" },
  { id: 2, name: "Health Potion", type: "consumable", effect: "heal" },
];

const starterQuests = [
  {
    id: 1,
    title: "Beginner's Trial",
    description: "Defeat the Goblin in the enchanted forest.",
    completed: false,
    xpReward: 60,
    goldReward: 50,
  },
  {
    id: 2,
    title: "Rescue the Merchant",
    description: "Help a merchant trapped in the mystical mountains.",
    completed: false,
    xpReward: 120,
    goldReward: 100,
  },
];

const enemyGoblin = {
  name: "Goblin",
  hp: 50,
  maxHp: 50,
  strength: 8,
};

const locations = [
  "Enchanted Forest",
  "Mystical Mountains",
  "Crystal Castle",
  "Shadow Town",
  "Silver Lake",
];

function App() {
  // Character creation state
  const [character, setCharacter] = useState({
    name: "",
    race: RACES[0],
    charClass: CLASSES[0],
    stats: { ...INITIAL_STATS },
    inventory: [...starterInventory],
    quests: [...starterQuests],
    skills: {
      sword: 1,
      magic: 1,
      stealth: 1,
    },
  });

  const [tab, setTab] = useState(TABS.PROFILE);
  const [characterCreated, setCharacterCreated] = useState(false);

  // Combat state
  const [inCombat, setInCombat] = useState(false);
  const [combatEnemy, setCombatEnemy] = useState(null);
  const [combatLog, setCombatLog] = useState([]);
  const [questInCombat, setQuestInCombat] = useState(null);

  // Add XP and check for level up
  const addXp = (amount) => {
    setCharacter((c) => {
      let newXp = c.stats.xp + amount;
      let newLevel = c.stats.level;
      let newXpToNext = c.stats.xpToNext;
      let levelGained = 0;

      while (newXp >= newXpToNext) {
        newXp -= newXpToNext;
        newLevel++;
        newXpToNext = Math.round(newXpToNext * 1.5);
        levelGained++;
      }

      return {
        ...c,
        stats: {
          ...c.stats,
          xp: newXp,
          level: newLevel,
          xpToNext: newXpToNext,
          skillPoints: c.stats.skillPoints + levelGained,
          maxHp: c.stats.maxHp + levelGained * 10,
          maxMp: c.stats.maxMp + levelGained * 6,
          strength: c.stats.strength + levelGained * 2,
          intelligence: c.stats.intelligence + levelGained * 2,
          agility: c.stats.agility + levelGained * 1,
          hp: c.stats.hp + levelGained * 10,
          mp: c.stats.mp + levelGained * 6,
        },
      };
    });
  };

  // Character creation handler
  const createCharacter = () => {
    if (!character.name.trim()) {
      alert("Please enter a character name.");
      return;
    }
    let newStats = { ...INITIAL_STATS };
    if (character.race === "Elf") newStats.intelligence += 5;
    if (character.race === "Dwarf") newStats.strength += 5;
    if (character.charClass === "Mage") newStats.mp += 30;
    if (character.charClass === "Warrior") newStats.strength += 7;
    if (character.charClass === "Rogue") newStats.agility += 7;
    newStats.hp = newStats.maxHp;
    newStats.mp = newStats.maxMp;
    setCharacter((c) => ({ ...c, stats: newStats }));
    setCharacterCreated(true);
    setTab(TABS.PROFILE);
  };

  // Use consumable item
  const useItem = (item) => {
    if (item.type === "consumable" && item.effect === "heal") {
      setCharacter((c) => {
        let newHp = Math.min(c.stats.hp + 50, c.stats.maxHp);
        let newInv = c.inventory.filter((i) => i.id !== item.id);
        return {
          ...c,
          stats: { ...c.stats, hp: newHp },
          inventory: newInv,
        };
      });
    }
  };

  // Upgrade a skill if skill points available
  const upgradeSkill = (skill) => {
    if (character.stats.skillPoints <= 0) return;
    setCharacter((c) => ({
      ...c,
      skills: {
        ...c.skills,
        [skill]: c.skills[skill] + 1,
      },
      stats: {
        ...c.stats,
        skillPoints: c.stats.skillPoints - 1,
      },
    }));
  };

  // Start combat for quest
  const startCombat = (quest) => {
    if (inCombat) return;
    if (quest.completed) return;
    setCombatEnemy({ ...enemyGoblin });
    setCombatLog([`A wild Goblin appears for: "${quest.title}"`]);
    setInCombat(true);
    setQuestInCombat(quest);
    setTab(TABS.COMBAT);
  };

  // Player attacks enemy
  const playerAttack = () => {
    if (!inCombat || !combatEnemy) return;

    const damage =
      character.stats.strength +
      character.skills.sword * 2 +
      Math.floor(Math.random() * 5);

    let enemyHp = combatEnemy.hp - damage;
    enemyHp = enemyHp < 0 ? 0 : enemyHp;

    let log = [`You strike the ${combatEnemy.name} for ${damage} damage.`];

    if (enemyHp === 0) {
      log.push(`${combatEnemy.name} is defeated!`);
      endCombat(true);
    } else {
      // Enemy attacks back
      let goblinDamage = combatEnemy.strength + Math.floor(Math.random() * 3);
      let playerHp = character.stats.hp - goblinDamage;
      playerHp = playerHp < 0 ? 0 : playerHp;

      log.push(`${combatEnemy.name} hits you for ${goblinDamage} damage.`);

      setCharacter((c) => ({
        ...c,
        stats: {
          ...c.stats,
          hp: playerHp,
        },
      }));

      if (playerHp === 0) {
        log.push("You have been defeated...");
        endCombat(false);
      }
    }

    setCombatEnemy((e) => ({ ...e, hp: enemyHp }));
    setCombatLog((l) => [...l, ...log]);
  };

  // End combat and update quest/character stats
  const endCombat = (playerWon) => {
    setInCombat(false);
    if (!questInCombat) {
      setTab(TABS.QUESTS);
      return;
    }

    if (playerWon) {
      setCharacter((c) => ({
        ...c,
        quests: c.quests.map((q) =>
          q.id === questInCombat.id ? { ...q, completed: true } : q
        ),
        stats: {
          ...c.stats,
          gold: c.stats.gold + questInCombat.goldReward,
        },
      }));
      setTimeout(() => {
        addXp(questInCombat.xpReward);
      }, 300);
      alert(
        `Quest "${questInCombat.title}" completed! You earned ${questInCombat.xpReward} XP and ${questInCombat.goldReward} gold.`
      );
    } else {
      alert("You failed the quest, better luck next time!");
    }
    setQuestInCombat(null);
    setTab(TABS.QUESTS);
  };

  if (!characterCreated) {
    return (
      <div style={{ padding: 20, fontFamily: "'Segoe UI', Tahoma, Geneva" }}>
        <h1>Create your fantasy character</h1>
        <label>
          Name:{" "}
          <input
            value={character.name}
            onChange={(e) =>
              setCharacter({ ...character, name: e.target.value })
            }
            style={{ marginBottom: 10 }}
          />
        </label>
        <br />
        <label>
          Race:{" "}
          <select
            value={character.race}
            onChange={(e) =>
              setCharacter({ ...character, race: e.target.value })
            }
            style={{ marginBottom: 10 }}
          >
            {RACES.map((r) => (
              <option key={r}>{r}</option>
            ))}
          </select>
        </label>
        <br />
        <label>
          Class:{" "}
          <select
            value={character.charClass}
            onChange={(e) =>
              setCharacter({ ...character, charClass: e.target.value })
            }
            style={{ marginBottom: 10 }}
          >
            {CLASSES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <br />
        <button onClick={createCharacter}>Create Character</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 20, fontFamily: "'Segoe UI', Tahoma, Geneva" }}>
      <h1>Fantasy RPG Adventure</h1>
      <nav style={{ marginBottom: 20 }}>
        {Object.values(TABS).map((t) => (
          <button
            key={t}
            style={{
              marginRight: 10,
              fontWeight: tab === t ? "bold" : "normal",
            }}
            onClick={() => {
              if (!inCombat || (inCombat && t === TABS.COMBAT)) setTab(t);
            }}
            disabled={inCombat && t !== TABS.COMBAT}
          >
            {t}
          </button>
        ))}
      </nav>

      {tab === TABS.PROFILE && (
        <section>
          <h2>Character Profile</h2>
          <p>
            <b>Name:</b> {character.name}
          </p>
          <p>
            <b>Race:</b> {character.race}
          </p>
          <p>
            <b>Class:</b> {character.charClass}
          </p>
          <p>
            <b>Level:</b> {character.stats.level} (XP:{" "}
            {character.stats.xp} / {character.stats.xpToNext})
          </p>
          <p>
            <b>HP:</b> {character.stats.hp} / {character.stats.maxHp}
          </p>
          <p>
            <b>MP:</b> {character.stats.mp} / {character.stats.maxMp}
          </p>
          <p>
            <b>Strength:</b> {character.stats.strength}
          </p>
          <p>
            <b>Intelligence:</b> {character.stats.intelligence}
          </p>
          <p>
            <b>Agility:</b> {character.stats.agility}
          </p>
          <p>
            <b>Gold:</b> {character.stats.gold}
          </p>
          <p>
            <b>Skill Points:</b> {character.stats.skillPoints}
          </p>
        </section>
      )}

      {tab === TABS.INVENTORY && (
        <section>
          <h2>Inventory</h2>
          {character.inventory.length === 0 && <p>Your inventory is empty.</p>}
          <ul>
            {character.inventory.map((item) => (
              <li key={item.id} style={{ marginBottom: "6px" }}>
                {item.name}{" "}
                {item.type === "consumable" && (
                  <button onClick={() => useItem(item)}>Use</button>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === TABS.QUESTS && (
        <section>
          <h2>Quests</h2>
          {character.quests.length === 0 && <p>No quests available.</p>}
          <ul>
            {character.quests.map((q) => (
              <li
                key={q.id}
                style={{ marginBottom: "12px", paddingBottom: 6, borderBottom: "1px solid #ccc" }}
              >
                <b>{q.title}</b> -{" "}
                {q.completed ? (
                  <span style={{ color: "green" }}>Completed</span>
                ) : (
                  <span style={{ color: "red" }}>Incomplete</span>
                )}
                <br />
                <i>{q.description}</i>
                <br />
                {!q.completed && (
                  <button onClick={() => startCombat(q)}>Start Quest Combat</button>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === TABS.COMBAT && (
        <section>
          <h2>Combat</h2>
          {inCombat && combatEnemy ? (
            <div>
              <p>
                <b>{combatEnemy.name}</b> HP: {combatEnemy.hp} / {combatEnemy.maxHp}
              </p>
              <p>
                <b>{character.name}</b> HP: {character.stats.hp} / {character.stats.maxHp}
              </p>
              <button onClick={playerAttack} disabled={!inCombat}>
                Attack
              </button>
              <div
                style={{
                  border: "1px solid black",
                  padding: 10,
                  marginTop: 15,
                  maxHeight: 200,
                  overflowY: "auto",
                  backgroundColor: "#f0f0f0",
                }}
              >
                {combatLog.map((msg, i) => (
                  <p key={i} style={{ margin: 0 }}>
                    {msg}
                  </p>
                ))}
              </div>
            </div>
          ) : (
            <p>No active combat</p>
          )}
          {!inCombat && (
            <button onClick={() => setTab(TABS.QUESTS)}>Back to Quests</button>
          )}
        </section>
      )}

      {tab === TABS.SKILLS && (
        <section>
          <h2>Skills</h2>
          <p>Skill Points: <b>{character.stats.skillPoints}</b></p>
          <ul>
            {Object.entries(character.skills).map(([skill, level]) => (
              <li key={skill} style={{ marginBottom: 10 }}>
                {skill.charAt(0).toUpperCase() + skill.slice(1)}: Level {level}{" "}
                <button onClick={() => upgradeSkill(skill)} disabled={character.stats.skillPoints <= 0}>
                  Upgrade
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === TABS.MAP && (
        <section>
          <h2>World Map</h2>
          <p>Welcome to the fantasy world! Explore these locations:</p>
          <ul>
            {locations.map((loc) => (
              <li key={loc}>{loc}</li>
            ))}
          </ul>
          <p><i>Traveling functionality coming soon!</i></p>
        </section>
      )}
    </div>
  );
}

export default App;
